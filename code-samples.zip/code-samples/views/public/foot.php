<?php
/**
 * Global footer file for public html space
 * @author Jason Wright <jason.dee.wright@gmail.com>
 * @since November 18, 2014
 */ 
?>
<div class="container">
    <div class="footer">
        <p>&copy; <?=date('Y')?> Scottsdale Diamonds Inc.</p>
    </div>
</div>